﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BoxScore
{
    /// <summary>
    /// Interaction logic for Creator.xaml
    /// </summary>
    public partial class Creator : Window
    {
        public Creator()
        {
            string filePath = "pack://application:,,,/ImageResources/Themes/" + WindowManager.theme + "/create.png";
            this.Background = new ImageBrush(new BitmapImage(new Uri(filePath)));
            InitializeComponent();
        }

        private void MatchButton_Click(object sender, RoutedEventArgs e)
        {
            Matchcreate mc = new Matchcreate();
            mc.Show();
            this.Close();
        }

        private void TeamButton_Click(object sender, RoutedEventArgs e)
        {
            Teamcreate tc = new Teamcreate();
            tc.Show();
            this.Close();
        }

        private void PlayerButton_Click(object sender, RoutedEventArgs e)
        {
            Playercreate pc = new Playercreate();
            pc.Show();
            this.Close();
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to Log Out?", "Reminder", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                Navigator nav = new Navigator();
                nav.Show();
                this.Close();
            }
        }
    }
}
