﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BoxScore
{
    /// <summary>
    /// Interaction logic for Navigator.xaml
    /// </summary>
    public partial class Navigator : Window
    {
        public Navigator()
        {
            string filePath = "pack://application:,,,/ImageResources/Themes/" + WindowManager.theme + "/navigator.png";
            this.Background = new ImageBrush(new BitmapImage(new Uri(filePath)));

            InitializeComponent();

        }

        private void CreateButton_Click(object sender, RoutedEventArgs e)
        {
            Login log = new Login();
            log.Show();
            this.Close();
        }

        private void ScoresButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void LeaderButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void ViewButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void SwitchButton_Click(object sender, RoutedEventArgs e)
        {
            if(WindowManager.theme.Equals("lighttheme"))
                WindowManager.theme = "darktheme";
            else if (WindowManager.theme.Equals("darktheme"))
                WindowManager.theme = "lighttheme";

            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }
    }
}
