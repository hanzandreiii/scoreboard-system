﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace BoxScore
{

    public partial class MainWindow : Window
    {
        DispatcherTimer time = new DispatcherTimer();
        int count = 0;
        public MainWindow()
        {
            string filePath = "pack://application:,,,/ImageResources/Themes/" + WindowManager.theme + "/loading.png";
            this.Background = new ImageBrush(new BitmapImage(new Uri(filePath)));

            InitializeComponent();
   
            time.Interval = new TimeSpan(0, 0, 0, 0, 18);
            time.Tick += Time_Tick;
            time.Start();
        }

        void Time_Tick(object sender, EventArgs e)
        { 
            string[] loadarray = new string[] { "load1", "load2", "load3", "load4", "load4", "load4", "load4", "load5", "load6", "load7", "load7", "load7", "load7", "load7", "load7", "load8", "load8" };
            string[] loadtable = new string[] { "1", "2", "3", "4", "4", "4", "4", "5", "6", "7", "7", "7", "7", "7", "7", "8", "8" };
            string filePath = "pack://application:,,,/ImageResources/Loadscreen/" + loadarray[count] + ".png";
            Load.Source = (ImageSource)new ImageSourceConverter().ConvertFromString(filePath);
            lbl.Content = "Loading Tables " + loadtable[count] + "/8";
            count++;
            if (count == loadarray.Length)
            {
                time.Stop();
                Navigator nav = new Navigator();
                nav.Show();
                this.Close();
            }
        }
    }
}
