﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BoxScore
{
    /// <summary>
    /// Interaction logic for Matchcreate.xaml
    /// </summary>
    public partial class Matchcreate : Window
    {
        private BoxScoreDBDataContext db_con = new BoxScoreDBDataContext(Properties.Settings.Default.BoxScoreConnectionString);
        private static int status = 0;
        private static int onechangecount = 0;
        private static int twochangecount = 0;
        public Matchcreate()
        {
            string filePath = "pack://application:,,,/ImageResources/Themes/" + WindowManager.theme + "/default.png";
            this.Background = new ImageBrush(new BitmapImage(new Uri(filePath)));

            InitializeComponent();
            BoxTwo.IsEnabled = false;
            BoxAdd();
        }
        private void BoxAdd()
        {
            foreach (var s in db_con.tbl_Teams)
            {
                int count = db_con.PlayerCount(s.Team_Name).Count();
                if (count >= 5)
                {
                    BoxOne.Items.Add(s.Team_Name);
                    BoxTwo.Items.Add(s.Team_Name);
                }
            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            if (status == 0)
            {
                Creator cr = new Creator();
                cr.Show();
                this.Close();
            }
            else
            {
                if (MessageBox.Show("Are you sure you want to lose your progress?", "Reminder", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    Creator cr = new Creator();
                    cr.Show();
                    this.Close();
                }
            }
        }

        private void BoxOne_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string logoone = "";

            status = 1;

            BoxTwo.IsEnabled = true;

            if (onechangecount > 0)
                BoxTwo.Items.Add(WindowManager.teamone);

            WindowManager.teamone = BoxOne.SelectedItem.ToString();

            BoxTwo.Items.Remove(WindowManager.teamone);

            foreach (var s in db_con.tbl_Teams)
            {
                if (WindowManager.teamone == s.Team_Name)
                    logoone = s.Team_Logo.ToString();
                    
            }
            string filePath = "pack://application:,,,/ImageResources/TeamLogos/" + logoone + "";
            imgone.Source = (ImageSource)new ImageSourceConverter().ConvertFromString(filePath);
            onechangecount++;
        }

        private void BoxTwo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string logotwo = "";

            if (twochangecount > 0)
                BoxOne.Items.Add(WindowManager.teamtwo);

            WindowManager.teamtwo = BoxTwo.SelectedItem.ToString();

            BoxOne.Items.Remove(WindowManager.teamtwo);

            foreach (var s in db_con.tbl_Teams)
            {
                if (WindowManager.teamtwo == s.Team_Name)
                    logotwo = s.Team_Logo.ToString();

            }
            string filePath = "pack://application:,,,/ImageResources/TeamLogos/" + logotwo + "";
            imgtwo.Source = (ImageSource)new ImageSourceConverter().ConvertFromString(filePath);
            twochangecount++;
        }

        private void CreateButton_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Proceed to the game?", "Reminder", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                string[] teams = new string[2];
                foreach (var s in db_con.tbl_Teams)
                {
                    if (s.Team_Name == WindowManager.teamone)
                        teams[0] = s.Team_ID;
                    if (s.Team_Name == WindowManager.teamtwo)
                        teams[1] = s.Team_ID;
                }

                WindowManager.teamoneid = teams[0];
                WindowManager.teamtwoid = teams[1];
                int count = db_con.MatchCount().Count();
                count = count + 1;

                string id = "match" + count + "";

                db_con.MatchInsert(id, teams[0], teams[1]);

                WindowManager.match = id;

                onechangecount = 1;
                twochangecount = 1;
                int fieldcountone = 1;
                int fieldcounttwo = 6;

                foreach (var s in db_con.tbl_Players)
                {
                    if(onechangecount <= 5 && s.Team_Name.Equals(WindowManager.teamone))
                    {
                        string fieldID = "FIELDID-" + string.Format("{0:00}", fieldcountone) + "";
                        string pos = "pos" + onechangecount + "";
                        db_con.FieldUpdate(fieldID, s.Player_ID, pos, teams[0]);
                        onechangecount++;
                        fieldcountone++;
                    }

                    if (twochangecount <= 5 && s.Team_Name.Equals(WindowManager.teamtwo))
                    {
                        string fieldID = "FIELDID-" + string.Format("{0:00}", fieldcounttwo) + "";
                        string pos = "pos" + twochangecount + "";
                        db_con.FieldUpdate(fieldID, s.Player_ID, pos, teams[1]);
                        twochangecount++;
                        fieldcounttwo++;
                    }
                }

                MessageBox.Show("Match has been created!");
                GameWindow gw = new GameWindow();
                gw.Show();
                this.Close();
            }
        }
    }
}
