﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BoxScore
{
    /// <summary>
    /// Interaction logic for GameWindow.xaml
    /// </summary>
    public partial class GameWindow : Window
    {
        private BoxScoreDBDataContext db_con = new BoxScoreDBDataContext(Properties.Settings.Default.BoxScoreConnectionString);
        public GameWindow()
        {
            
            InitializeComponent();
            lblAddOne();
            lblAddTwo();
            ButtonDisabler("allfunc", false);
            nameone.Content = WindowManager.teamone;
            nametwo.Content = WindowManager.teamtwo;
        }
        private void lblAddOne()
        {
            string id = "";
            string playername = "";
            string points = "";
            string stats = "";
            string fieldID = "FIELDID-01";
            string tempplayer = "";
            foreach (var s in db_con.tbl_PlayerScores)
            {
                id = s.Match_ID.ToString().Trim();
                if (id.Equals(WindowManager.match)) 
                {
                    foreach (var j in db_con.tbl_Fields)
                    {
                        if (j.Field_ID.ToString().Trim().Equals(fieldID) && j.Team_ID.ToString().Trim().Equals(WindowManager.teamoneid))
                        {
                            foreach (var n in db_con.tbl_Players )
                            {
                                if (n.Player_ID == j.Player_ID && n.Player_ID.ToString() != tempplayer)
                                {
                                    playername = n.Player_LN.ToString().Trim() + ", " + n.Player_FN.ToString().Trim();
                                 
                                    switch (fieldID)
                                    {
                                        case "FIELDID-01":
                                            pos1name.Content = playername + "";
                                            points = s.Player_PTS.ToString() + "";
                                            pos1pts.Content = points + "";
                                            stats = " " + s.Player_FGP.ToString().PadLeft(3, '0') + "  " + s.Player_3PP.ToString().PadLeft(3, '0') + "  " + s.Player_FTP.ToString().PadLeft(3, '0') +
                                         "   " + s.Player_REB.ToString().PadLeft(3, '0') + "  " + s.Player_AST.ToString().PadLeft(3, '0') + "  " + s.Player_STL.ToString().PadLeft(3, '0') +
                                          "   " + s.Player_BLK.ToString().PadLeft(3, '0') + "  " + s.Player_PF.ToString().PadLeft(3, '0');
                                            pos1stats.Content = stats + "";
                                            fieldID = "FIELDID-02";
                                            break;
                                        case "FIELDID-02":
                                            pos2name.Content = playername + "";
                                            points = s.Player_PTS.ToString() + "";
                                            pos2pts.Content = points + "";
                                            stats = " " + s.Player_FGP.ToString().PadLeft(3, '0') + "  " + s.Player_3PP.ToString().PadLeft(3, '0') + "  " + s.Player_FTP.ToString().PadLeft(3, '0') +
                                         "   " + s.Player_REB.ToString().PadLeft(3, '0') + "  " + s.Player_AST.ToString().PadLeft(3, '0') + "  " + s.Player_STL.ToString().PadLeft(3, '0') +
                                          "   " + s.Player_BLK.ToString().PadLeft(3, '0') + "  " + s.Player_PF.ToString().PadLeft(3, '0');
                                            pos2stats.Content = stats + "";
                                            fieldID = "FIELDID-03";
                                            break;
                                        case "FIELDID-03":
                                            pos3name.Content = playername + "";
                                            points = s.Player_PTS.ToString() + "";
                                            pos3pts.Content = points + "";
                                            stats = " " + s.Player_FGP.ToString().PadLeft(3, '0') + "  " + s.Player_3PP.ToString().PadLeft(3, '0') + "  " + s.Player_FTP.ToString().PadLeft(3, '0') +
                                         "   " + s.Player_REB.ToString().PadLeft(3, '0') + "  " + s.Player_AST.ToString().PadLeft(3, '0') + "  " + s.Player_STL.ToString().PadLeft(3, '0') +
                                          "   " + s.Player_BLK.ToString().PadLeft(3, '0') + "  " + s.Player_PF.ToString().PadLeft(3, '0');
                                            pos3stats.Content = stats + "";
                                            fieldID = "FIELDID-04";
                                            break;
                                        case "FIELDID-04":
                                            pos4name.Content = playername + "";
                                            points = s.Player_PTS.ToString() + "";
                                            pos4pts.Content = points + "";
                                            stats = " " + s.Player_FGP.ToString().PadLeft(3, '0') + "  " + s.Player_3PP.ToString().PadLeft(3, '0') + "  " + s.Player_FTP.ToString().PadLeft(3, '0') +
                                         "   " + s.Player_REB.ToString().PadLeft(3, '0') + "  " + s.Player_AST.ToString().PadLeft(3, '0') + "  " + s.Player_STL.ToString().PadLeft(3, '0') +
                                          "   " + s.Player_BLK.ToString().PadLeft(3, '0') + "  " + s.Player_PF.ToString().PadLeft(3, '0');
                                            pos4stats.Content = stats + "";
                                            fieldID = "FIELDID-05";
                                            break;
                                        case "FIELDID-05":
                                            pos5name.Content = playername + "";
                                            points = s.Player_PTS.ToString() + "";
                                            pos5pts.Content = points + "";
                                            stats = " " + s.Player_FGP.ToString().PadLeft(3, '0') + "  " + s.Player_3PP.ToString().PadLeft(3, '0') + "  " + s.Player_FTP.ToString().PadLeft(3, '0') +
                                         "   " + s.Player_REB.ToString().PadLeft(3, '0') + "  " + s.Player_AST.ToString().PadLeft(3, '0') + "  " + s.Player_STL.ToString().PadLeft(3, '0') +
                                          "   " + s.Player_BLK.ToString().PadLeft(3, '0') + "  " + s.Player_PF.ToString().PadLeft(3, '0');
                                            pos5stats.Content = stats + "";
                                            break;
                                    }
                                    tempplayer = n.Player_ID.ToString();
                                    break;
                                }
                            }
                        }
                    }
                }               
            }
        }
        private void lblAddTwo()
        {
            string id = "";
            string playername = "";
            string points = "";
            string stats = "";
            string fieldID = "FIELDID-06";
            string tempplayer = "";

            foreach (var s in db_con.tbl_PlayerScores)
            {
                id = s.Match_ID.ToString().Trim();
                if (id.Equals(WindowManager.match))
                {
                    foreach (var j in db_con.tbl_Fields)
                    {
                        if (j.Field_ID.ToString().Trim().Equals(fieldID) && j.Team_ID.ToString().Trim().Equals(WindowManager.teamtwoid))
                        {
                            foreach (var n in db_con.tbl_Players)
                            {
                                if (n.Player_ID == j.Player_ID && n.Player_ID.ToString() != tempplayer)
                                {
                                    playername = n.Player_LN.ToString().Trim() + ", " + n.Player_FN.ToString().Trim();
                                    points = s.Player_PTS.ToString() + "";

                                    switch (fieldID)
                                    {
                                        case "FIELDID-06":
                                            pos6name.Content = playername + "";
                                            points = s.Player_PTS.ToString() + "";
                                            pos6pts.Content = points + "";
                                            stats = " " + s.Player_FGP.ToString().PadLeft(3, '0') + "  " + s.Player_3PP.ToString().PadLeft(3, '0') + "  " + s.Player_FTP.ToString().PadLeft(3, '0') +
                                         "   " + s.Player_REB.ToString().PadLeft(3, '0') + "  " + s.Player_AST.ToString().PadLeft(3, '0') + "  " + s.Player_STL.ToString().PadLeft(3, '0') +
                                          "   " + s.Player_BLK.ToString().PadLeft(3, '0') + "  " + s.Player_PF.ToString().PadLeft(3, '0');
                                            pos6stats.Content = stats + "";
                                            fieldID = "FIELDID-07";
                                            break;
                                        case "FIELDID-07":
                                            pos7name.Content = playername + "";
                                            points = s.Player_PTS.ToString() + "";
                                            pos7pts.Content = points + "";
                                            stats = " " + s.Player_FGP.ToString().PadLeft(3, '0') + "  " + s.Player_3PP.ToString().PadLeft(3, '0') + "  " + s.Player_FTP.ToString().PadLeft(3, '0') +
                                         "   " + s.Player_REB.ToString().PadLeft(3, '0') + "  " + s.Player_AST.ToString().PadLeft(3, '0') + "  " + s.Player_STL.ToString().PadLeft(3, '0') +
                                          "   " + s.Player_BLK.ToString().PadLeft(3, '0') + "  " + s.Player_PF.ToString().PadLeft(3, '0');
                                            pos7stats.Content = stats + "";
                                            fieldID = "FIELDID-08";
                                            break;
                                        case "FIELDID-08":
                                            pos8name.Content = playername + "";
                                            points = s.Player_PTS.ToString() + "";
                                            pos8pts.Content = points + "";
                                            stats = " " + s.Player_FGP.ToString().PadLeft(3, '0') + "  " + s.Player_3PP.ToString().PadLeft(3, '0') + "  " + s.Player_FTP.ToString().PadLeft(3, '0') +
                                         "   " + s.Player_REB.ToString().PadLeft(3, '0') + "  " + s.Player_AST.ToString().PadLeft(3, '0') + "  " + s.Player_STL.ToString().PadLeft(3, '0') +
                                          "   " + s.Player_BLK.ToString().PadLeft(3, '0') + "  " + s.Player_PF.ToString().PadLeft(3, '0');
                                            pos8stats.Content = stats + "";
                                            fieldID = "FIELDID-09";
                                            break;
                                        case "FIELDID-09":
                                            pos9name.Content = playername + "";
                                            points = s.Player_PTS.ToString() + "";
                                            pos9pts.Content = points + "";
                                            stats = " " + s.Player_FGP.ToString().PadLeft(3, '0') + "  " + s.Player_3PP.ToString().PadLeft(3, '0') + "  " + s.Player_FTP.ToString().PadLeft(3, '0') +
                                         "   " + s.Player_REB.ToString().PadLeft(3, '0') + "  " + s.Player_AST.ToString().PadLeft(3, '0') + "  " + s.Player_STL.ToString().PadLeft(3, '0') +
                                          "   " + s.Player_BLK.ToString().PadLeft(3, '0') + "  " + s.Player_PF.ToString().PadLeft(3, '0');
                                            pos9stats.Content = stats + "";
                                            fieldID = "FIELDID-10";
                                            break;
                                        case "FIELDID-10":
                                            pos10name.Content = playername + "";
                                            points = s.Player_PTS.ToString() + "";
                                            pos10pts.Content = points + "";
                                            stats = " " + s.Player_FGP.ToString().PadLeft(3, '0') + "  " + s.Player_3PP.ToString().PadLeft(3, '0') + "  " + s.Player_FTP.ToString().PadLeft(3, '0') +
                                         "   " + s.Player_REB.ToString().PadLeft(3, '0') + "  " + s.Player_AST.ToString().PadLeft(3, '0') + "  " + s.Player_STL.ToString().PadLeft(3, '0') +
                                          "   " + s.Player_BLK.ToString().PadLeft(3, '0') + "  " + s.Player_PF.ToString().PadLeft(3, '0');
                                            pos10stats.Content = stats + "";
                                            break;
                                    }
                                    tempplayer = n.Player_ID.ToString();
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }

        private void ButtonDisabler(string choice, bool status)
        {
            if (choice.Equals("allfunc"))
            {
                FGButton.IsEnabled = status;
                TPButton.IsEnabled = status;
                FTButton.IsEnabled = status;
                REBButton.IsEnabled = status;
                ASTButton.IsEnabled = status;
                BLKButton.IsEnabled = status;
                STLButton.IsEnabled = status;
                PFButton.IsEnabled = status;
                ADDButton.IsEnabled = status;
                ATTButton.IsEnabled = status;
                CANButton.IsEnabled = status;
            }
            if (choice.Equals("allplayers"))
            {
                POS1Button.IsEnabled = status;
                POS2Button.IsEnabled = status;
                POS3Button.IsEnabled = status;
                POS4Button.IsEnabled = status;
                POS5Button.IsEnabled = status;
                POS6Button.IsEnabled = status;
                POS7Button.IsEnabled = status;
                POS8Button.IsEnabled = status;
                POS9Button.IsEnabled = status;
                POS10Button.IsEnabled = status;
            }
            if (choice.Equals("funcclickone"))
            {
                if (FGButton.IsEnabled == true)
                    FGButton.IsEnabled = false;
                if (TPButton.IsEnabled == true)
                    TPButton.IsEnabled = false;
                if (FTButton.IsEnabled == true)
                    FTButton.IsEnabled = false;
                if (REBButton.IsEnabled == true)
                    REBButton.IsEnabled = false;
                if (ASTButton.IsEnabled == true)
                    ASTButton.IsEnabled = false;
                if (BLKButton.IsEnabled == true)
                    BLKButton.IsEnabled = false;
                if (STLButton.IsEnabled == true)
                    STLButton.IsEnabled = false;
                if (PFButton.IsEnabled == true)
                    PFButton.IsEnabled = false;

                ADDButton.IsEnabled = true;
                ATTButton.IsEnabled = false;
                CANButton.IsEnabled = true;
            }
            if (choice.Equals("funcclicktwo"))
            {
                if (FGButton.IsEnabled == true)
                    FGButton.IsEnabled = false;
                if (TPButton.IsEnabled == true)
                    TPButton.IsEnabled = false;
                if (FTButton.IsEnabled == true)
                    FTButton.IsEnabled = false;
                if (REBButton.IsEnabled == true)
                    REBButton.IsEnabled = false;
                if (ASTButton.IsEnabled == true)
                    ASTButton.IsEnabled = false;
                if (BLKButton.IsEnabled == true)
                    BLKButton.IsEnabled = false;
                if (STLButton.IsEnabled == true)
                    STLButton.IsEnabled = false;
                if (PFButton.IsEnabled == true)
                    PFButton.IsEnabled = false;

                ADDButton.IsEnabled = true;
                ATTButton.IsEnabled = true;
                CANButton.IsEnabled = true;
            }
            if (choice.Equals("cancel"))
            {
                FGButton.IsEnabled = true;
                TPButton.IsEnabled = true;
                FTButton.IsEnabled = true;
                ASTButton.IsEnabled = true;
                BLKButton.IsEnabled = true;
                STLButton.IsEnabled = true;
                PFButton.IsEnabled = true;
                ADDButton.IsEnabled = false;
                ATTButton.IsEnabled = false;
                CANButton.IsEnabled = false;
            }
            if (choice.Equals("repick"))
            {
                if (POS1Button.IsEnabled == false)
                    POS1Button.IsEnabled = true;
                if (POS2Button.IsEnabled == false)
                    POS2Button.IsEnabled = true;
                if (POS3Button.IsEnabled == false)
                    POS3Button.IsEnabled = true;
                if (POS4Button.IsEnabled == false)
                    POS4Button.IsEnabled = true;
                if (POS5Button.IsEnabled == false)
                    POS5Button.IsEnabled = true;
                if (POS6Button.IsEnabled == false)
                    POS6Button.IsEnabled = true;
                if (POS7Button.IsEnabled == false)
                    POS7Button.IsEnabled = true;
                if (POS8Button.IsEnabled == false)
                    POS8Button.IsEnabled = true;
                if (POS9Button.IsEnabled == false)
                    POS9Button.IsEnabled = true;
                if (POS10Button.IsEnabled == false)
                    POS10Button.IsEnabled = true;

                FGButton.IsEnabled = true;
                TPButton.IsEnabled = true;
                FTButton.IsEnabled = true;
                ASTButton.IsEnabled = true;
                BLKButton.IsEnabled = true;
                STLButton.IsEnabled = true;
                PFButton.IsEnabled = true;
                ADDButton.IsEnabled = false;
                ATTButton.IsEnabled = false;
                CANButton.IsEnabled = false;
            }
        }


        ///POSITION BUTTONS START ===========================================================================================

        private void POS1Button_Click(object sender, RoutedEventArgs e)
        {
            foreach (var s in db_con.tbl_Fields)
            {
                if (s.Field_ID.Equals("FIELDID-01"))
                    WindowManager.playerchoice = s.Player_ID.ToString();
            }
            WindowManager.teamchoice = WindowManager.teamone;
            POS1Button.IsEnabled = false;
            ButtonDisabler("repick", true);
            ButtonDisabler("allfunc", true);
        }

        private void POS2Button_Click(object sender, RoutedEventArgs e)
        {
            foreach (var s in db_con.tbl_Fields)
            {
                if (s.Field_ID.Equals("FIELDID-02"))
                    WindowManager.playerchoice = s.Player_ID.ToString();
            }
            WindowManager.teamchoice = WindowManager.teamone;
            POS2Button.IsEnabled = false;
            ButtonDisabler("repick", true);
            ButtonDisabler("allfunc", true);
        }

        private void POS3Button_Click(object sender, RoutedEventArgs e)
        {
            foreach (var s in db_con.tbl_Fields)
            {
                if (s.Field_ID.Equals("FIELDID-03"))
                    WindowManager.playerchoice = s.Player_ID.ToString();
            }
            WindowManager.teamchoice = WindowManager.teamone;
            POS3Button.IsEnabled = false;
            ButtonDisabler("repick", true);
            ButtonDisabler("allfunc", true);
        }

        private void POS4Button_Click(object sender, RoutedEventArgs e)
        {
            foreach (var s in db_con.tbl_Fields)
            {
                if (s.Field_ID.Equals("FIELDID-04"))
                    WindowManager.playerchoice = s.Player_ID.ToString();
            }
            WindowManager.teamchoice = WindowManager.teamone;
            POS4Button.IsEnabled = false;
            ButtonDisabler("repick", true);
            ButtonDisabler("allfunc", true);
        }

        private void POS5Button_Click(object sender, RoutedEventArgs e)
        {
            foreach (var s in db_con.tbl_Fields)
            {
                if (s.Field_ID.Equals("FIELDID-05"))
                    WindowManager.playerchoice = s.Player_ID.ToString();
            }
            WindowManager.teamchoice = WindowManager.teamone;
            POS5Button.IsEnabled = false;
            ButtonDisabler("repick", true);
            ButtonDisabler("allfunc", true);
        }

        private void POS6Button_Click(object sender, RoutedEventArgs e)
        {
            foreach (var s in db_con.tbl_Fields)
            {
                if (s.Field_ID.Equals("FIELDID-06"))
                    WindowManager.playerchoice = s.Player_ID.ToString();
            }
            WindowManager.teamchoice = WindowManager.teamtwo;
            POS6Button.IsEnabled = false;
            ButtonDisabler("repick", true);
            ButtonDisabler("allfunc", true);
        }

        private void POS7Button_Click(object sender, RoutedEventArgs e)
        {
            foreach (var s in db_con.tbl_Fields)
            {
                if (s.Field_ID.Equals("FIELDID-07"))
                    WindowManager.playerchoice = s.Player_ID.ToString();
            }
            WindowManager.teamchoice = WindowManager.teamtwo;
            POS7Button.IsEnabled = false;
            ButtonDisabler("repick", true);
            ButtonDisabler("allfunc", true);
        }

        private void POS8Button_Click(object sender, RoutedEventArgs e)
        {
            foreach (var s in db_con.tbl_Fields)
            {
                if (s.Field_ID.Equals("FIELDID-08"))
                    WindowManager.playerchoice = s.Player_ID.ToString();
            }
            WindowManager.teamchoice = WindowManager.teamtwo;
            POS8Button.IsEnabled = false;
            ButtonDisabler("repick", true);
            ButtonDisabler("allfunc", true);
        }

        private void POS9Button_Click(object sender, RoutedEventArgs e)
        {
            foreach (var s in db_con.tbl_Fields)
            {
                if (s.Field_ID.Equals("FIELDID-09"))
                    WindowManager.playerchoice = s.Player_ID.ToString();
            }
            WindowManager.teamchoice = WindowManager.teamtwo;
            POS9Button.IsEnabled = false;
            ButtonDisabler("repick", true);
            ButtonDisabler("allfunc", true);
        }

        private void POS10Button_Click(object sender, RoutedEventArgs e)
        {
            foreach (var s in db_con.tbl_Fields)
            {
                if (s.Field_ID.Equals("FIELDID-10"))
                    WindowManager.playerchoice = s.Player_ID.ToString();
            }
            WindowManager.teamchoice = WindowManager.teamtwo;
            POS10Button.IsEnabled = false;
            ButtonDisabler("repick", true);
            ButtonDisabler("allfunc", true);
        }


        ///POSITION BUTTONS END ===========================================================================================
        ///GAME BUTTONS START ===========================================================================================

        private void FGButton_Click(object sender, RoutedEventArgs e)
        {
            WindowManager.insertchoice = 1;
            FGButton.IsEnabled = false;
            ButtonDisabler("funcclickone", true);
        }

        private void TPButton_Click(object sender, RoutedEventArgs e)
        {
            WindowManager.insertchoice = 2;
            TPButton.IsEnabled = false;
            ButtonDisabler("funcclickone", true);
        }

        private void FTButton_Click(object sender, RoutedEventArgs e)
        {
            WindowManager.insertchoice = 3;
            FTButton.IsEnabled = false;
            ButtonDisabler("funcclickone", true);
        }

        private void REBButton_Click(object sender, RoutedEventArgs e)
        {
            WindowManager.insertchoice = 4;
            REBButton.IsEnabled = false;
            ButtonDisabler("funcclicktwo", true);
        }

        private void ASTButton_Click(object sender, RoutedEventArgs e)
        {
            WindowManager.insertchoice = 5;
            ASTButton.IsEnabled = false;
            ButtonDisabler("funcclicktwo", true);
        }

        private void BLKButton_Click(object sender, RoutedEventArgs e)
        {
            WindowManager.insertchoice = 6;
            BLKButton.IsEnabled = false;
            ButtonDisabler("funcclicktwo", true);
        }

        private void STLButton_Click(object sender, RoutedEventArgs e)
        {
            WindowManager.insertchoice = 7;
            STLButton.IsEnabled = false;
            ButtonDisabler("funcclicktwo", true);
        }

        private void PFButton_Click(object sender, RoutedEventArgs e)
        {
            WindowManager.insertchoice = 8;
            PFButton.IsEnabled = false;
            ButtonDisabler("funcclicktwo", true);
        }

        /*'PLAYER-060', @MatchID = 'match1', @TeamName = 'Phoenix Suns', @SeasonID = 'season2',
@FGM = '0', @FGA = '0', @3PM = '1', @3PA = '0', 
@FTM = '0', @FTA = '0', @REB = '0', @AST = '0', 
@STL = '0', @BLK = '0', @PF = '0', @PTS = '0'
*/
        private void ADDButton_Click(object sender, RoutedEventArgs e)
        {
            switch(WindowManager.insertchoice)
            {
                case 1:
                    db_con.Retally(WindowManager.playerchoice, WindowManager.match, WindowManager.teamchoice, "season2", 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
                    break;
                case 2:
                    db_con.Retally(WindowManager.playerchoice, WindowManager.match, WindowManager.teamchoice, "season2", 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0);
                    break;
                case 3:
                    db_con.Retally(WindowManager.playerchoice, WindowManager.match, WindowManager.teamchoice, "season2", 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0);
                    break;
                case 4:
                    db_con.Retally(WindowManager.playerchoice, WindowManager.match, WindowManager.teamchoice, "season2", 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0);
                    break;
                case 5:
                    db_con.Retally(WindowManager.playerchoice, WindowManager.match, WindowManager.teamchoice, "season2", 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0);
                    break;
                case 6:
                    db_con.Retally(WindowManager.playerchoice, WindowManager.match, WindowManager.teamchoice, "season2", 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0);
                    break;
                case 7:
                    db_con.Retally(WindowManager.playerchoice, WindowManager.match, WindowManager.teamchoice, "season2", 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0);
                    break;
                case 8:
                    db_con.Retally(WindowManager.playerchoice, WindowManager.match, WindowManager.teamchoice, "season2", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0);
                    break;
            }
            ButtonDisabler("allfunc", false);
            ButtonDisabler("allplayers", true);
            lblAddOne();
            lblAddTwo();
        }

        private void ATTButton_Click(object sender, RoutedEventArgs e)
        {
            switch (WindowManager.insertchoice)
            {
                case 1:
                    db_con.Retally(WindowManager.playerchoice, WindowManager.match, WindowManager.teamchoice, "season2", 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
                    break;
                case 2:
                    db_con.Retally(WindowManager.playerchoice, WindowManager.match, WindowManager.teamchoice, "season2", 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0);
                    break;
                case 3:
                    db_con.Retally(WindowManager.playerchoice, WindowManager.match, WindowManager.teamchoice, "season2", 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0);
                    break;
            }
            ButtonDisabler("allfunc", false);
            ButtonDisabler("allplayers", true);
        }

        private void CANButton_Click(object sender, RoutedEventArgs e)
        {
            ButtonDisabler("allfunc", true);
            ADDButton.IsEnabled = false;
            ATTButton.IsEnabled = false;
            CANButton.IsEnabled = false;
            ButtonDisabler("allplayers", true);
        }

        ///GAME BUTTONS END ===========================================================================================
    

        ///SUB BUTTONS START ===========================================================================================
      

        private void SUBButton1_Click(object sender, RoutedEventArgs e)
        {

        }

        private void SUBButton2_Click(object sender, RoutedEventArgs e)
        {

        }

        ///SUB BUTTONS END ===========================================================================================
    }
}
