﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BoxScore
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        private BoxScoreDBDataContext db_con = new BoxScoreDBDataContext(Properties.Settings.Default.BoxScoreConnectionString);
        public Login()
        {
            string filePath = "pack://application:,,,/ImageResources/Themes/" + WindowManager.theme + "/default.png";
            this.Background = new ImageBrush(new BitmapImage(new Uri(filePath)));
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            int count = 0;

            count = db_con.Login(userbox.Text.ToString(), passbox.Text.ToString()).Count();

            if (count == 1)
            {
                Creator cr = new Creator();
                cr.Show();
                this.Close();
            }
            else
                MessageBox.Show("Info was not found in the registry, please try again");
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            Navigator nav = new Navigator();
            nav.Show();
            this.Close();
        }
    }
}
