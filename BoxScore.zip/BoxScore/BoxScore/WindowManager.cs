﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BoxScore
{
    internal class WindowManager
    {
        public static string theme = "lighttheme";
        public static int logincon = 0;
        public static string teamone = "";
        public static string teamtwo = "";
        public static string teamoneid = "";
        public static string teamtwoid = "";
        public static string match = "";
        public static int insertchoice = 0;
        public static string playerchoice = "";
        public static string teamchoice = "";
        public static string pos1id = "";
        public static string pos2id = "";
        public static string pos3id = "";
        public static string pos4id = "";
        public static string pos5id = "";
        public static string pos6id = "";
        public static string pos7id = "";
        public static string pos8id = "";
        public static string pos9id = "";
        public static string pos10id = "";

    }
}
